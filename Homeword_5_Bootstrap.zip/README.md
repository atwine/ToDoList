# ToDoList
My To Do List Flast App
In this app I was learning how to build simple Flask Apps.

This is the very first one I have built so far. This marks a journey of growth in this area of Flask and app building.

